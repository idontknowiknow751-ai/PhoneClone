package com.example.phoneclone;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Phone Clone: เครื่องโทรศัพท์จำลองที่มีหลายหน้าจอ
 * - ปัดซ้าย/ขวาเพื่อเปลี่ยนหน้าจอ
 * - กดเครื่องหมาย + เพื่อเลือกแอป/เกมที่ติดตั้งอยู่มาวางในหน้านั้น
 * - กดค้างที่ไอคอนเพื่อลบ/ย้ายหน้า
 * - มี Dock ด้านล่าง, วอลเปเปอร์ไล่สี, นาฬิกาและแบตเตอรี่
 */
public class MainActivity extends Activity {

    private static final int COLS = 4;
    private static final int ROWS = 5;
    private static final int PER_PAGE = COLS * ROWS;
    private static final int DOCK_MAX = 4;
    private static final int PAGE_MAX = 10;

    private static final int[][] WALLS = {
            {0xFF1A237E, 0xFF7B1FA2},
            {0xFF004D40, 0xFF26A69A},
            {0xFFBF360C, 0xFFFFB300},
            {0xFF212121, 0xFF607D8B},
            {0xFF0D47A1, 0xFF00ACC1}
    };

    private final List<List<String>> pages = new ArrayList<>();
    private final List<String> dock = new ArrayList<>();
    private int cur = 0;
    private int wall = 0;

    private PackageManager pm;
    private SharedPreferences prefs;
    private LinearLayout root;
    private FrameLayout pageHost;
    private LinearLayout dotsRow;
    private LinearLayout dockBar;
    private TextView clock;
    private TextView battery;
    private GestureDetector gd;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            updateStatus();
            handler.postDelayed(this, 20_000);
        }
    };

    // ------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pm = getPackageManager();
        prefs = getSharedPreferences("clone", MODE_PRIVATE);
        load();
        buildUi();
        gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                if (a == null || b == null) return false;
                float dx = b.getX() - a.getX();
                float dy = b.getY() - a.getY();
                if (Math.abs(dx) > dpi(80) && Math.abs(dx) > Math.abs(dy) * 1.5f && Math.abs(vx) > 400) {
                    go(dx < 0 ? 1 : -1);
                    return true;
                }
                return false;
            }
        });
        render(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(ticker);
        render(0); // เผื่อมีการติดตั้ง/ถอนแอประหว่างที่ออกไป
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (gd != null) gd.onTouchEvent(ev);
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public void onBackPressed() {
        // เป็นแอปโฮม: ปุ่ม Back กลับไปหน้าจอแรกแทนการปิด
        if (cur != 0) {
            int dir = -1;
            cur = 0;
            save();
            renderPage(dir);
            renderDots();
        }
    }

    // ------------------------------------------------------------ storage

    private void load() {
        try {
            JSONObject o = new JSONObject(prefs.getString("state", "{}"));
            JSONArray p = o.optJSONArray("pages");
            if (p != null) {
                for (int i = 0; i < p.length(); i++) {
                    JSONArray a = p.getJSONArray(i);
                    List<String> l = new ArrayList<>();
                    for (int j = 0; j < a.length(); j++) l.add(a.getString(j));
                    pages.add(l);
                }
            }
            JSONArray d = o.optJSONArray("dock");
            if (d != null) {
                for (int i = 0; i < d.length(); i++) dock.add(d.getString(i));
            }
            wall = o.optInt("wall", 0);
            cur = o.optInt("cur", 0);
        } catch (Exception ignored) {
        }
        if (pages.isEmpty()) pages.add(new ArrayList<String>());
        if (wall < 0 || wall >= WALLS.length) wall = 0;
        cur = Math.max(0, Math.min(cur, pages.size() - 1));
    }

    private void save() {
        try {
            JSONObject o = new JSONObject();
            JSONArray p = new JSONArray();
            for (List<String> l : pages) {
                JSONArray a = new JSONArray();
                for (String s : l) a.put(s);
                p.put(a);
            }
            o.put("pages", p);
            JSONArray d = new JSONArray();
            for (String s : dock) d.put(s);
            o.put("dock", d);
            o.put("wall", wall);
            o.put("cur", cur);
            prefs.edit().putString("state", o.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------ helpers

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private int dpi(float v) {
        return Math.round(dp(v));
    }

    private boolean launchable(String pkg) {
        return pm.getLaunchIntentForPackage(pkg) != null;
    }

    private Drawable iconOf(String pkg) {
        try {
            return pm.getApplicationIcon(pkg);
        } catch (Exception e) {
            return null;
        }
    }

    private CharSequence labelOf(String pkg) {
        try {
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0));
        } catch (Exception e) {
            return pkg;
        }
    }

    private void prune(List<String> list) {
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            if (!launchable(it.next())) it.remove();
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------ UI

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setFitsSystemWindows(true);

        // แถบสถานะจำลอง
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dpi(20), dpi(8), dpi(12), dpi(8));

        clock = new TextView(this);
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(16);
        clock.setTypeface(Typeface.DEFAULT_BOLD);
        bar.addView(clock, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        battery = new TextView(this);
        battery.setTextColor(Color.WHITE);
        battery.setTextSize(13);
        bar.addView(battery, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView menu = new TextView(this);
        menu.setText("⋮");
        menu.setTextColor(Color.WHITE);
        menu.setTextSize(22);
        menu.setGravity(Gravity.CENTER);
        menu.setPadding(dpi(14), 0, dpi(10), 0);
        menu.setOnClickListener(v -> showMenu());
        bar.addView(menu, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // พื้นที่หน้าจอ
        pageHost = new FrameLayout(this);
        pageHost.setPadding(dpi(8), dpi(8), dpi(8), 0);
        root.addView(pageHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // จุดบอกหน้า (กดค้างเพื่อเปิดเมนู)
        dotsRow = new LinearLayout(this);
        dotsRow.setOrientation(LinearLayout.HORIZONTAL);
        dotsRow.setGravity(Gravity.CENTER);
        dotsRow.setPadding(0, dpi(6), 0, dpi(6));
        dotsRow.setOnLongClickListener(v -> {
            showMenu();
            return true;
        });
        root.addView(dotsRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dpi(28)));

        // Dock
        dockBar = new LinearLayout(this);
        dockBar.setOrientation(LinearLayout.HORIZONTAL);
        dockBar.setGravity(Gravity.CENTER);
        dockBar.setPadding(dpi(8), dpi(10), dpi(8), dpi(10));
        GradientDrawable dockBg = new GradientDrawable();
        dockBg.setColor(0x33FFFFFF);
        dockBg.setCornerRadius(dp(28));
        dockBar.setBackground(dockBg);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.setMargins(dpi(14), 0, dpi(14), dpi(14));
        root.addView(dockBar, dlp);

        setContentView(root);
    }

    private void render(int dir) {
        for (List<String> l : pages) prune(l);
        prune(dock);

        GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, WALLS[wall]);
        root.setBackground(g);

        renderPage(dir);
        renderDots();
        renderDock();
        updateStatus();
    }

    private void renderPage(int dir) {
        View v = buildPage(cur);
        pageHost.removeAllViews();
        pageHost.addView(v, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (dir != 0) {
            int w = pageHost.getWidth() > 0 ? pageHost.getWidth() : getResources().getDisplayMetrics().widthPixels;
            v.setTranslationX(dir * w);
            v.animate().translationX(0).setDuration(220).start();
        }
    }

    private View buildPage(int index) {
        final List<String> list = pages.get(index);
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);

        for (int r = 0; r < ROWS; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < COLS; c++) {
                int i = r * COLS + c;
                View cell;
                if (i < list.size()) {
                    cell = appCell(list.get(i), list, true, false);
                } else if (i == list.size()) {
                    cell = addCell(list);
                } else {
                    cell = new View(this);
                }
                row.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
            }
            grid.addView(row, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        }
        return grid;
    }

    private void renderDots() {
        dotsRow.removeAllViews();
        for (int i = 0; i < pages.size(); i++) {
            View d = new View(this);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColor(i == cur ? Color.WHITE : 0x66FFFFFF);
            d.setBackground(bg);
            int size = dpi(i == cur ? 9 : 7);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            lp.setMargins(dpi(4), 0, dpi(4), 0);
            dotsRow.addView(d, lp);
        }
    }

    private void renderDock() {
        dockBar.removeAllViews();
        for (int i = 0; i < DOCK_MAX; i++) {
            View cell;
            if (i < dock.size()) {
                cell = appCell(dock.get(i), dock, false, true);
            } else if (i == dock.size()) {
                cell = addCell(dock);
            } else {
                cell = new View(this);
            }
            dockBar.addView(cell, new LinearLayout.LayoutParams(0, dpi(64), 1f));
        }
    }

    private View appCell(final String pkg, final List<String> list, boolean showLabel, final boolean isDock) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dpi(2), dpi(4), dpi(2), dpi(4));

        ImageView iv = new ImageView(this);
        iv.setImageDrawable(iconOf(pkg));
        c.addView(iv, new LinearLayout.LayoutParams(dpi(isDock ? 46 : 52), dpi(isDock ? 46 : 52)));

        if (showLabel) {
            TextView tv = new TextView(this);
            tv.setText(labelOf(pkg));
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(11);
            tv.setSingleLine(true);
            tv.setEllipsize(android.text.TextUtils.TruncateAt.END);
            tv.setGravity(Gravity.CENTER);
            tv.setShadowLayer(3f, 0f, 1f, 0xAA000000);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dpi(3);
            c.addView(tv, lp);
        }

        c.setOnClickListener(v -> launch(pkg));
        c.setOnLongClickListener(v -> {
            itemMenu(pkg, list, isDock);
            return true;
        });
        return c;
    }

    private View addCell(final List<String> list) {
        LinearLayout c = new LinearLayout(this);
        c.setGravity(Gravity.CENTER);
        TextView plus = new TextView(this);
        plus.setText("+");
        plus.setTextColor(Color.WHITE);
        plus.setTextSize(26);
        plus.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0x22FFFFFF);
        bg.setStroke(dpi(2), 0x88FFFFFF);
        plus.setBackground(bg);
        c.addView(plus, new LinearLayout.LayoutParams(dpi(46), dpi(46)));
        final boolean isDock = list == dock;
        c.setOnClickListener(v -> showPicker(list, isDock));
        return c;
    }

    // ------------------------------------------------------------ actions

    private void updateStatus() {
        if (clock == null) return;
        clock.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
        try {
            Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b != null) {
                int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                if (level >= 0 && scale > 0) {
                    battery.setText("🔋 " + (level * 100 / scale) + "%");
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void launch(String pkg) {
        Intent i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) {
            toast("เปิดแอปนี้ไม่ได้ (อาจถูกถอนการติดตั้งแล้ว)");
            render(0);
            return;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Exception e) {
            toast("เปิดแอปไม่สำเร็จ");
        }
    }

    private void go(int dir) {
        int n = cur + dir;
        if (n < 0 || n >= pages.size()) return;
        cur = n;
        save();
        renderPage(dir);
        renderDots();
    }

    private void showMenu() {
        final List<String> labels = new ArrayList<>();
        final List<Integer> ids = new ArrayList<>();
        if (pages.size() < PAGE_MAX) {
            labels.add("เพิ่มหน้าจอใหม่");
            ids.add(0);
        }
        if (pages.size() > 1) {
            labels.add("ลบหน้าจอนี้");
            ids.add(1);
        }
        labels.add("เปลี่ยนวอลเปเปอร์");
        ids.add(2);
        labels.add("ตั้งเป็นแอปโฮมของเครื่อง");
        ids.add(3);

        new AlertDialog.Builder(this)
                .setTitle("เมนู")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    switch (ids.get(which)) {
                        case 0:
                            pages.add(new ArrayList<String>());
                            cur = pages.size() - 1;
                            save();
                            render(1);
                            break;
                        case 1:
                            confirmDeletePage();
                            break;
                        case 2:
                            wall = (wall + 1) % WALLS.length;
                            save();
                            render(0);
                            break;
                        case 3:
                            try {
                                startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
                            } catch (Exception e) {
                                toast("เปิดหน้าตั้งค่าไม่ได้ ไปที่ ตั้งค่า > แอป > แอปเริ่มต้น > แอปโฮม");
                            }
                            break;
                    }
                })
                .show();
    }

    private void confirmDeletePage() {
        new AlertDialog.Builder(this)
                .setTitle("ลบหน้าจอที่ " + (cur + 1) + " ?")
                .setMessage("ไอคอนในหน้านี้จะถูกเอาออก (ไม่ได้ถอนการติดตั้งแอป)")
                .setNegativeButton("ยกเลิก", null)
                .setPositiveButton("ลบ", (d, w) -> {
                    pages.remove(cur);
                    if (cur >= pages.size()) cur = pages.size() - 1;
                    save();
                    render(0);
                })
                .show();
    }

    private void itemMenu(final String pkg, final List<String> list, final boolean isDock) {
        final List<String> labels = new ArrayList<>();
        final List<Integer> ids = new ArrayList<>();
        labels.add("เปิด");
        ids.add(0);
        labels.add("เอาออกจากเครื่องโคลน");
        ids.add(1);
        if (!isDock) {
            if (cur > 0) {
                labels.add("ย้ายไปหน้าจอก่อนหน้า");
                ids.add(2);
            }
            if (cur < pages.size() - 1) {
                labels.add("ย้ายไปหน้าจอถัดไป");
                ids.add(3);
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(labelOf(pkg))
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    switch (ids.get(which)) {
                        case 0:
                            launch(pkg);
                            break;
                        case 1:
                            list.remove(pkg);
                            save();
                            render(0);
                            break;
                        case 2:
                            moveTo(pkg, list, cur - 1);
                            break;
                        case 3:
                            moveTo(pkg, list, cur + 1);
                            break;
                    }
                })
                .show();
    }

    private void moveTo(String pkg, List<String> from, int target) {
        List<String> to = pages.get(target);
        if (to.size() >= PER_PAGE) {
            toast("หน้าจอปลายทางเต็มแล้ว");
            return;
        }
        from.remove(pkg);
        to.add(pkg);
        save();
        render(0);
    }

    // ------------------------------------------------------------ picker

    private static class App {
        String pkg;
        CharSequence label;
        Drawable icon;
    }

    private void showPicker(final List<String> target, final boolean isDock) {
        if (isDock && dock.size() >= DOCK_MAX) return;
        if (!isDock && target.size() >= PER_PAGE) {
            toast("หน้าจอเต็มแล้ว");
            return;
        }

        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> rs = pm.queryIntentActivities(q, 0);

        Set<String> taken = new HashSet<>(target);
        Set<String> seen = new HashSet<>();
        final List<App> apps = new ArrayList<>();
        for (ResolveInfo ri : rs) {
            String p = ri.activityInfo.packageName;
            if (p.equals(getPackageName()) || taken.contains(p) || !seen.add(p)) continue;
            App a = new App();
            a.pkg = p;
            a.label = ri.loadLabel(pm);
            a.icon = ri.loadIcon(pm);
            apps.add(a);
        }
        Collections.sort(apps, new Comparator<App>() {
            @Override
            public int compare(App x, App y) {
                return x.label.toString().compareToIgnoreCase(y.label.toString());
            }
        });

        if (apps.isEmpty()) {
            toast("ไม่พบแอปให้เพิ่ม");
            return;
        }

        BaseAdapter adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return apps.size();
            }

            @Override
            public Object getItem(int i) {
                return apps.get(i);
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(int i, View convert, ViewGroup parent) {
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dpi(16), dpi(8), dpi(16), dpi(8));
                ImageView iv = new ImageView(MainActivity.this);
                iv.setImageDrawable(apps.get(i).icon);
                row.addView(iv, new LinearLayout.LayoutParams(dpi(40), dpi(40)));
                TextView tv = new TextView(MainActivity.this);
                tv.setText(apps.get(i).label);
                tv.setTextSize(16);
                tv.setPadding(dpi(14), 0, 0, 0);
                row.addView(tv, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                return row;
            }
        };

        new AlertDialog.Builder(this)
                .setTitle("เลือกแอป/เกมใส่ในเครื่องโคลน")
                .setAdapter(adapter, (d, which) -> {
                    target.add(apps.get(which).pkg);
                    save();
                    render(0);
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }
}
